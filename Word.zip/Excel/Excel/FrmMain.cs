﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using E = Microsoft.Office.Interop.Excel;

namespace AcademicScheduleTable
{
    public partial class Excel : Form
    {
        private DataTable dataTable;
        private DataGridView dataGridView;
        public Excel()
        {
            InitializeComponent();
            InitializeDataTable();
            InitializeComponents();
        }

        private object ParseIntOrNull(string value)
        {
            int result;
            if (int.TryParse(value, out result))
                return result;
            return DBNull.Value;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(1300, 650);
            this.Text = "Генератор учебного плана";
            this.ResumeLayout(false);
        }

        private void InitializeComponents()
        {
            // Создаем кнопки
            Button btnPreview = new Button();
            btnPreview.Text = "Предпросмотр";
            btnPreview.Location = new System.Drawing.Point(50, 550);
            btnPreview.Size = new System.Drawing.Size(120, 40);
            btnPreview.Click += BtnPreview_Click;
            this.Controls.Add(btnPreview);

            Button btnFillData = new Button();
            btnFillData.Text = "Загрузить данные";
            btnFillData.Location = new System.Drawing.Point(200, 550);
            btnFillData.Size = new System.Drawing.Size(120, 40);
            btnFillData.Click += BtnFillData_Click;
            this.Controls.Add(btnFillData);

            Button btnExportExcel = new Button();
            btnExportExcel.Text = "Экспорт в Excel";
            btnExportExcel.Location = new System.Drawing.Point(350, 550);
            btnExportExcel.Size = new System.Drawing.Size(120, 40);
            btnExportExcel.Click += BtnExportExcel_Click;
            this.Controls.Add(btnExportExcel);

            // DataGridView
            dataGridView = new DataGridView();
            dataGridView.Location = new System.Drawing.Point(50, 50);
            dataGridView.Size = new System.Drawing.Size(1200, 450);
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.DataSource = dataTable;

            // Настройка ширины колонок
            ConfigureDataGridViewColumns();

            this.Controls.Add(dataGridView);
        }

        private void BtnAddRow_Click(object sender, EventArgs e)
        {
            // Добавляем новую пустую строку перед итоговой
            int lastRowIndex = dataTable.Rows.Count - 1;
            DataRow newRow = dataTable.NewRow();

            // Автоматически нумеруем новую строку
            if (lastRowIndex > 0)
            {
                int lastNumber;
                if (int.TryParse(dataTable.Rows[lastRowIndex - 1]["№ п/п"].ToString(), out lastNumber))
                {
                    newRow["№ п/п"] = (lastNumber + 1).ToString();
                }
            }

            // Вставляем новую строку перед итоговой
            dataTable.Rows.InsertAt(newRow, lastRowIndex);
        }

        private void ConfigureDataGridViewColumns()
        {
            if (dataGridView.Columns.Count == 0) return;

            dataGridView.Columns[0].Width = 60;  // № п/п
            dataGridView.Columns[1].Width = 250; // Наименование дисциплин
            dataGridView.Columns[2].Width = 120; // всего часов в год
            dataGridView.Columns[3].Width = 180; // переаттестация часов
            dataGridView.Columns[4].Width = 120; // аул. часов в год
            dataGridView.Columns[5].Width = 140; // аул. часов в семестре
            dataGridView.Columns[6].Width = 140; // аул. часы в неделю
            dataGridView.Columns[7].Width = 180; // лекцион секционных проект, газетные
            dataGridView.Columns[8].Width = 120; // Форма аттестации

            // Установка обработчика событий для проверки ввода
            dataGridView.CellValidating += DataGridView_CellValidating;
        }

        private void DataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            // Проверяем только числовые колонки (индексы 2-6)
            if (e.ColumnIndex >= 2 && e.ColumnIndex <= 6)
            {
                string newValue = e.FormattedValue.ToString();
                if (!string.IsNullOrEmpty(newValue))
                {
                    int result;
                    if (!int.TryParse(newValue, out result))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Введите только цифры в это поле");
                    }
                }
            }
        }

        private void InitializeDataTable()
        {
            dataTable = new DataTable();

            // Создаем колонки точно по макету
            dataTable.Columns.Add("№ п/п", typeof(string));
            dataTable.Columns.Add("Наименование дисциплин", typeof(string));
            dataTable.Columns.Add("всего часов в год", typeof(int));
            dataTable.Columns.Add("переаттестация часов по нормативы, учебы, плану", typeof(int));
            dataTable.Columns.Add("аул. часов в год", typeof(int));
            dataTable.Columns.Add("аул. часов в семестре", typeof(int));
            dataTable.Columns.Add("аул. часы в неделю", typeof(int));
            dataTable.Columns.Add("лекцион секционных проект, газетные", typeof(string));
            dataTable.Columns.Add("Форма аттестации", typeof(string));

            // Данные точно по макету
            dataTable.Rows.Add("1", "Иностранный язык", 340, 68, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);
            dataTable.Rows.Add("2", "Гражданское право", 684, 153, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);
            dataTable.Rows.Add("3", "Судебная статистика", 40, 36, 36, 2, 1, "1", "Зачет");
            dataTable.Rows.Add("", "ИТОГО:", 1064, 257, 36, 2, 1, "1", "Экзаменов 0, зачетов 1");
        }

        private void BtnPreview_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Функция предпросмотра будет реализована позже");
        }

        private void BtnFillData_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                openFileDialog.Title = "Выберите файл с данными";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    string[] lines = File.ReadAllLines(filePath);

                    // Сохраняем итоговую строку
                    DataRow totalRow = dataTable.Rows[dataTable.Rows.Count - 1];

                    dataTable.Rows.Clear();

                    foreach (string line in lines)
                    {
                        if (!string.IsNullOrWhiteSpace(line))
                        {
                            string[] item = line.Split(';');
                            if (item.Length >= 9)
                            {
                                DataRow newRow = dataTable.NewRow();
                                newRow["№ п/п"] = item[0];
                                newRow["Наименование дисциплин"] = item[1];
                                newRow["всего часов в год"] = ParseIntOrNull(item[2]);
                                newRow["переаттестация часов по нормативы, учебы, плану"] = ParseIntOrNull(item[3]);
                                newRow["аул. часов в год"] = ParseIntOrNull(item[4]);
                                newRow["аул. часов в семестре"] = ParseIntOrNull(item[5]);
                                newRow["аул. часы в неделю"] = ParseIntOrNull(item[6]);
                                newRow["лекцион секционных проект, газетные"] = item[7];
                                newRow["Форма аттестации"] = item[8];

                                dataTable.Rows.Add(newRow);
                            }
                        }
                    }

                    // Добавляем обратно итоговую строку
                    dataTable.Rows.Add(totalRow.ItemArray);

                    MessageBox.Show("Данные успешно загружены!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            if (dataTable.Rows.Count == 0)
            {
                MessageBox.Show("Сначала загрузите данные!");
                return;
            }

            try
            {
                ExportToExcel();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportToExcel()
        {
            E.Application excelApp = null;
            E.Workbook workbook = null;
            E.Worksheet worksheet = null;

            try
            {
                excelApp = new E.Application();
                workbook = excelApp.Workbooks.Add();
                worksheet = workbook.ActiveSheet;

                excelApp.Visible = true;

                // Создаем трёхуровневую шапку
                CreateThreeLevelHeader(worksheet);

                // Данные таблицы (начинаем с 4 строки, так как шапка занимает 3 строки)
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    for (int j = 0; j < dataTable.Columns.Count; j++)
                    {
                        var cellValue = dataTable.Rows[i][j];
                        worksheet.Cells[i + 4, j + 1] = cellValue == DBNull.Value ? "" : cellValue.ToString();

                        // Выравнивание для числовых колонок
                        if (j >= 2 && j <= 6 && cellValue != DBNull.Value)
                        {
                            worksheet.Cells[i + 4, j + 1].NumberFormat = "0";
                            worksheet.Cells[i + 4, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignRight;
                        }
                        else
                        {
                            worksheet.Cells[i + 4, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignLeft;
                        }

                        // Границы для всех ячеек
                        worksheet.Cells[i + 4, j + 1].Borders.LineStyle = E.XlLineStyle.xlContinuous;

                        // Стиль для строки "ИТОГО"
                        if (dataTable.Rows[i]["Наименование дисциплин"].ToString() == "ИТОГО:")
                        {
                            worksheet.Cells[i + 4, j + 1].Font.Bold = true;
                            worksheet.Cells[i + 4, j + 1].Interior.Color =
                                System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                        }
                    }
                }

                // Настройка высоты строк
                worksheet.Rows[1].RowHeight = 20;
                worksheet.Rows[2].RowHeight = 20;
                worksheet.Rows[3].RowHeight = 25;
                for (int i = 4; i <= dataTable.Rows.Count + 3; i++)
                {
                    worksheet.Rows[i].RowHeight = 20;
                }

                // Сохранение файла - пользователь выбирает место
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*";
                saveDialog.FileName = "Учебный_план.xlsx";
                saveDialog.Title = "Выберите место для сохранения файла";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    MessageBox.Show($"Таблица успешно экспортирована в:\n{saveDialog.FileName}", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            finally
            {
                // Освобождение ресурсов
                if (workbook != null)
                {
                    workbook.Close(false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                }
                if (excelApp != null)
                {
                    excelApp.Quit();
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }
                if (worksheet != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                }
            }
        }

        private void CreateThreeLevelHeader(E.Worksheet worksheet)
        {
            // Настройка ширины колонок
            worksheet.Columns[1].ColumnWidth = 8;    // № п/п
            worksheet.Columns[2].ColumnWidth = 35;   // Наименование дисциплин
            worksheet.Columns[3].ColumnWidth = 12;   // всего часов в год
            worksheet.Columns[4].ColumnWidth = 18;   // переаттестация часов
            worksheet.Columns[5].ColumnWidth = 12;   // аул. часов в год
            worksheet.Columns[6].ColumnWidth = 15;   // аул. часов в семестре
            worksheet.Columns[7].ColumnWidth = 15;   // аул. часы в неделю
            worksheet.Columns[8].ColumnWidth = 20;   // лекцион секционных проект, газетные
            worksheet.Columns[9].ColumnWidth = 15;   // Форма аттестации

            // Первый уровень шапки (объединенные ячейки)
            worksheet.Cells[1, 1] = "№ п/п";
            worksheet.Cells[1, 2] = "Наименование дисциплин";
            worksheet.Cells[1, 3] = "Всего часов";
            worksheet.Cells[1, 4] = "Переаттестация";
            worksheet.Cells[1, 5] = "Аудиторные занятия";
            worksheet.Cells[1, 8] = "Виды занятий";
            worksheet.Cells[1, 9] = "Аттестация";

            // Объединение ячеек первого уровня
            worksheet.Range["A1:A3"].Merge(); // № п/п
            worksheet.Range["B1:B3"].Merge(); // Наименование дисциплин
            worksheet.Range["C1:C3"].Merge(); // Всего часов
            worksheet.Range["D1:D3"].Merge(); // Переаттестация
            worksheet.Range["E1:G1"].Merge(); // Аудиторные занятия
            worksheet.Range["H1:H3"].Merge(); // Виды занятий
            worksheet.Range["I1:I3"].Merge(); // Аттестация

            // Второй уровень шапки (только для аудиторных занятий)
            worksheet.Cells[2, 5] = "в год";
            worksheet.Cells[2, 6] = "в семестре";
            worksheet.Cells[2, 7] = "в неделю";

            // Объединение ячеек второго уровня
            worksheet.Range["E2:E3"].Merge(); // в год
            worksheet.Range["F2:F3"].Merge(); // в семестре
            worksheet.Range["G2:G3"].Merge(); // в неделю

            // Третий уровень шапки (детальные заголовки)
            string[] headers = {
                "№ п/п",
                "Наименование дисциплин",
                "всего часов в год",
                "переаттестация часов по нормативы, учебы, плану",
                "аул. часов в год",
                "аул. часов в семестре",
                "аул. часы в неделю",
                "лекцион секционных проект, газетные",
                "Форма аттестации"
            };

            // Стиль для всей шапки
            E.Range headerRange = worksheet.Range["A1:I3"];
            headerRange.Font.Bold = true;
            headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
            headerRange.HorizontalAlignment = E.XlHAlign.xlHAlignCenter;
            headerRange.VerticalAlignment = E.XlVAlign.xlVAlignCenter;
            headerRange.Borders.LineStyle = E.XlLineStyle.xlContinuous;
            headerRange.WrapText = true;

            // Установка значений для третьего уровня
            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cells[3, i + 1] = headers[i];
            }
        }
    }
}