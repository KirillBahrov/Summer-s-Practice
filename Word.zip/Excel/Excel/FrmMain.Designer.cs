﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AcademicScheduleTable
{
    partial class Excel
    {
        private System.ComponentModel.IContainer components = null;
        /*private System.Windows.Forms.Button btnExportToExcel;
        private System.Windows.Forms.Button btnFillData;
        private System.Windows.Forms.Button btnPreview;*/

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}