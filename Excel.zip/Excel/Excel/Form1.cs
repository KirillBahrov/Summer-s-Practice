﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Windows.Forms;
using E = Microsoft.Office.Interop.Excel;

namespace AcademicScheduleTable
{
    public partial class Excel : Form
    {
        private DataTable dataTable;
        private List<string[]> tableData;

        public Excel()
        {
            InitializeComponent();
            InitializeDataTable();
            InitializeComponents();
        }

        private object ParseIntOrNull(string value)
        {
            int result;
            if (int.TryParse(value, out result))
                return result;
            return DBNull.Value;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Text = "Генератор учебного плана";
            this.ResumeLayout(false);
        }

        private void InitializeComponents()
        {
            // Создаем кнопки
            Button btnPreview = new Button();
            btnPreview.Text = "Предпросмотр";
            btnPreview.Location = new System.Drawing.Point(50, 400);
            btnPreview.Size = new System.Drawing.Size(120, 40);
            btnPreview.Click += BtnPreview_Click;
            this.Controls.Add(btnPreview);

            Button btnFillData = new Button();
            btnFillData.Text = "Загрузить данные";
            btnFillData.Location = new System.Drawing.Point(200, 400);
            btnFillData.Size = new System.Drawing.Size(120, 40);
            btnFillData.Click += BtnFillData_Click;
            this.Controls.Add(btnFillData);

            Button btnExportExcel = new Button();
            btnExportExcel.Text = "Экспорт в Excel";
            btnExportExcel.Location = new System.Drawing.Point(350, 400);
            btnExportExcel.Size = new System.Drawing.Size(120, 40);
            btnExportExcel.Click += BtnExportExcel_Click;
            this.Controls.Add(btnExportExcel);

            // DataGridView
            DataGridView dataGridView = new DataGridView();
            dataGridView.DataSource = dataTable;
            dataGridView.Location = new System.Drawing.Point(50, 50);
            dataGridView.Size = new System.Drawing.Size(700, 300);
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Ограничение ввода только чисел
            dataGridView.EditingControlShowing += DataGridView_EditingControlShowing;

            this.Controls.Add(dataGridView);
        }

        private void DataGridView_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            TextBox txt = e.Control as TextBox;
            if (txt != null)
            {
                // Убираем старый обработчик, чтобы не дублировался
                txt.KeyPress -= Txt_KeyPress;

                int colIndex = ((DataGridView)sender).CurrentCell.ColumnIndex;
                // Числовые колонки: 2–6
                if (colIndex >= 2 && colIndex <= 6)
                {
                    txt.KeyPress += Txt_KeyPress;
                }
            }
        }

        private void Txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Разрешаем только цифры, Backspace и Delete
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void InitializeDataTable()
        {
            dataTable = new DataTable();


            // Создаем колонки
            dataTable.Columns.Add("№ п/п", typeof(string));
            dataTable.Columns.Add("Наименование дисциплин", typeof(string));
            dataTable.Columns.Add("всего часов в год", typeof(int));
            dataTable.Columns.Add("перекатывания часов по нормативному кабинету", typeof(int));
            dataTable.Columns.Add("ауди. часов в год", typeof(int));
            dataTable.Columns.Add("ауди. часов в сегменте", typeof(int));
            dataTable.Columns.Add("ауди. часы в неделю", typeof(int));
            dataTable.Columns.Add("периодичность (18 недель)", typeof(string));

            // Примерные данные
            dataTable.Rows.Add("1", "Иностранный язык", 340, 68, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);
            dataTable.Rows.Add("2", "Гражданское право", 684, 153, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value);
            dataTable.Rows.Add("3", "Судебная статистика", 40, 36, 36, 2, 1, "Зачет");
            dataTable.Rows.Add("", "ИТОГО:", 1064, 257, 36, 2, 1, "Экзаменов 0, зачетов 1");
        }

        private void BtnPreview_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Функция предпросмотра будет реализована позже");
        }

        private void BtnFillData_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath = "data.txt";
                if (!File.Exists(filePath))
                {
                    CreateSampleDataFile(filePath);
                }

                string[] lines = File.ReadAllLines(filePath);
                List<string[]> data = new List<string[]>();

                foreach (string line in lines)
                {
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        data.Add(line.Split(';'));
                    }
                }

                this.tableData = data;

                dataTable.Rows.Clear();
                foreach (string[] item in data)
                {
                    if (item.Length >= 8)
                    {
                        DataRow newRow = dataTable.NewRow();
                        newRow["№ п/п"] = item[0];
                        newRow["Наименование дисциплин"] = item[1];

                        newRow["всего часов в год"] = ParseIntOrNull(item[2]);
                        newRow["перекатывания часов по нормативному кабинету"] = ParseIntOrNull(item[3]);
                        newRow["ауди. часов в год"] = ParseIntOrNull(item[4]);
                        newRow["ауди. часов в сегменте"] = ParseIntOrNull(item[5]);
                        newRow["ауди. часы в неделю"] = ParseIntOrNull(item[6]);

                        newRow["периодичность (18 недель)"] = item[7];

                        dataTable.Rows.Add(newRow);
                    }
                }

                MessageBox.Show("Данные успешно загружены!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void CreateSampleDataFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("1;Иностранный язык;340;68;;;;");
                writer.WriteLine("2;Гражданское право;684;153;;;;");
                writer.WriteLine("3;Судебная статистика;40;36;36;2;1;Зачет");
                writer.WriteLine(";ИТОГО:;1064;257;36;2;1;Экзаменов 0, зачетов 1");
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            if (dataTable.Rows.Count == 0)
            {
                MessageBox.Show("Сначала загрузите данные!");
                return;
            }


            try
            {
                ExportToExcel();
                MessageBox.Show("Таблица успешно экспортирована в Excel!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportToExcel()
        {
            E.Application excelApp = new E.Application();
            E.Workbook workbook = excelApp.Workbooks.Add();
            E.Worksheet worksheet = workbook.ActiveSheet;

            excelApp.Visible = true;

            worksheet.Columns[1].ColumnWidth = 5;
            worksheet.Columns[2].ColumnWidth = 30;
            worksheet.Columns[3].ColumnWidth = 15;
            worksheet.Columns[4].ColumnWidth = 25;
            worksheet.Columns[5].ColumnWidth = 15;
            worksheet.Columns[6].ColumnWidth = 18;
            worksheet.Columns[7].ColumnWidth = 18;
            worksheet.Columns[8].ColumnWidth = 22;

            string[] headers = {
                "№ п/п",
                "Наименование дисциплин",
                "всего часов в год",
                "перекатывания часов по нормативному кабинету",
                "ауди. часов в год",
                "ауди. часов в сегменте",
                "ауди. часы в неделю",
                "периодичность (18 недель)"
            };

            for (int i = 0; i < headers.Length; i++)
            {
                worksheet.Cells[1, i + 1] = headers[i];
                worksheet.Cells[1, i + 1].Font.Bold = true;
                worksheet.Cells[1, i + 1].Interior.Color =
                    System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                worksheet.Cells[1, i + 1].HorizontalAlignment = E.XlHAlign.xlHAlignCenter;
                worksheet.Cells[1, i + 1].VerticalAlignment = E.XlVAlign.xlVAlignCenter;
                worksheet.Cells[1, i + 1].Borders.LineStyle = E.XlLineStyle.xlContinuous;
                worksheet.Cells[1, i + 1].WrapText = true;
            }

            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    var cellValue = dataTable.Rows[i][j];
                    worksheet.Cells[i + 2, j + 1] = cellValue == DBNull.Value ? "" : cellValue.ToString();

                    if (j >= 2 && j <= 6 && cellValue != DBNull.Value)
                    {
                        try
                        {
                            worksheet.Cells[i + 2, j + 1].NumberFormat = "0";
                            worksheet.Cells[i + 2, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignRight;
                        }
                        catch { }
                    }
                    else
                    {
                        worksheet.Cells[i + 2, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignLeft;
                    }

                    worksheet.Cells[i + 2, j + 1].Borders.LineStyle = E.XlLineStyle.xlContinuous;

                    if (i == dataTable.Rows.Count - 1)
                    {
                        worksheet.Cells[i + 2, j + 1].Font.Bold = true;
                        worksheet.Cells[i + 2, j + 1].Interior.Color =
                            System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                    }
                }
            }

            worksheet.Rows[1].RowHeight = 40;
            for (int i = 2; i <= dataTable.Rows.Count + 1; i++)
            {
                worksheet.Rows[i].RowHeight = 25;
            }

            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*";
            saveDialog.FileName = "Учебный_план.xlsx";

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                workbook.SaveAs(saveDialog.FileName);
            }


            workbook.Close(true);
            excelApp.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
        }
    }
}
