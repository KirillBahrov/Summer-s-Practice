﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using E = Microsoft.Office.Interop.Excel;

namespace AcademicScheduleTable
{
    public partial class Excel : Form
    {
        private DataTable dataTable;
        private DataGridView dataGridView;

        public Excel()
        {
            InitializeComponent();
            InitializeDataTable();
            InitializeComponents();
        }

        private object ParseIntOrNull(string value)
        {
            int result;
            if (int.TryParse(value, out result))
                return result;
            return DBNull.Value;
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.ClientSize = new System.Drawing.Size(1300, 650);
            this.Text = "Генератор учебного плана";
            this.ResumeLayout(false);
        }

        private void InitializeComponents()
        {
            // Кнопка Предпросмотр
            Button btnPreview = new Button();
            btnPreview.Text = "Предпросмотр";
            btnPreview.Location = new System.Drawing.Point(50, 550);
            btnPreview.Size = new System.Drawing.Size(120, 40);
            btnPreview.Click += BtnPreview_Click;
            this.Controls.Add(btnPreview);

            // Кнопка Загрузить данные
            Button btnFillData = new Button();
            btnFillData.Text = "Загрузить данные";
            btnFillData.Location = new System.Drawing.Point(200, 550);
            btnFillData.Size = new System.Drawing.Size(120, 40);
            btnFillData.Click += BtnFillData_Click;
            this.Controls.Add(btnFillData);

            // Кнопка Экспорт в Excel
            Button btnExportExcel = new Button();
            btnExportExcel.Text = "Экспорт в Excel";
            btnExportExcel.Location = new System.Drawing.Point(350, 550);
            btnExportExcel.Size = new System.Drawing.Size(120, 40);
            btnExportExcel.Click += BtnExportExcel_Click;
            this.Controls.Add(btnExportExcel);

            // Кнопка Заполнить шаблон
            Button btnLoadTemplate = new Button();
            btnLoadTemplate.Text = "Заполнить шаблон";
            btnLoadTemplate.Location = new System.Drawing.Point(500, 550);
            btnLoadTemplate.Size = new System.Drawing.Size(140, 40);
            btnLoadTemplate.Click += BtnLoadTemplate_Click;
            this.Controls.Add(btnLoadTemplate);

            // Кнопка Добавить строку
            Button btnAddRow = new Button();
            btnAddRow.Text = "Добавить строку";
            btnAddRow.Location = new System.Drawing.Point(660, 550);
            btnAddRow.Size = new System.Drawing.Size(140, 40);
            btnAddRow.Click += BtnAddRow_Click;
            this.Controls.Add(btnAddRow);

            // DataGridView
            dataGridView = new DataGridView();
            dataGridView.Location = new System.Drawing.Point(50, 50);
            dataGridView.Size = new System.Drawing.Size(1200, 450);
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.DataSource = dataTable;

            ConfigureDataGridViewColumns();

            this.Controls.Add(dataGridView);
        }

        private void BtnAddRow_Click(object sender, EventArgs e)
        {
            DataRow newRow = dataTable.NewRow();
            int lastRowIndex = dataTable.Rows.Count;

            // Автоматическая нумерация
            if (lastRowIndex > 0)
            {
                int lastNumber;
                if (int.TryParse(dataTable.Rows[lastRowIndex - 1]["№ п/п"].ToString(), out lastNumber))
                {
                    newRow["№ п/п"] = (lastNumber + 1).ToString();
                }
            }

            dataTable.Rows.Add(newRow);
        }

        private void ConfigureDataGridViewColumns()
        {
            if (dataGridView.Columns.Count == 0) return;

            dataGridView.Columns[0].Width = 60;   // № п/п
            dataGridView.Columns[1].Width = 250;  // Наименование дисциплин
            dataGridView.Columns[2].Width = 120;  // всего часов в год
            dataGridView.Columns[3].Width = 180;  // переаттестация
            dataGridView.Columns[4].Width = 120;  // ауд. часов в год
            dataGridView.Columns[5].Width = 140;  // ауд. часов в семестре
            dataGridView.Columns[6].Width = 140;  // всего
            dataGridView.Columns[7].Width = 180;  // лекции
            dataGridView.Columns[8].Width = 120;  // семинары
            dataGridView.Columns[9].Width = 120;  // форма аттестации
            dataGridView.Columns[10].Width = 160; // курсовая работа

            dataGridView.CellValidating += DataGridView_CellValidating;
        }

        private void DataGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex >= 2 && e.ColumnIndex <= 6)
            {
                string newValue = e.FormattedValue.ToString();
                if (!string.IsNullOrEmpty(newValue))
                {
                    int result;
                    if (!int.TryParse(newValue, out result))
                    {
                        e.Cancel = true;
                        MessageBox.Show("Введите только цифры в это поле");
                    }
                }
            }
        }

        private void InitializeDataTable()
        {
            dataTable = new DataTable();

            dataTable.Columns.Add("№ п/п", typeof(string));
            dataTable.Columns.Add("Наименование дисциплин", typeof(string));
            dataTable.Columns.Add("всего часов в год", typeof(int));
            dataTable.Columns.Add("Переаттестация часов по норматнен. учебн. плану", typeof(int));
            dataTable.Columns.Add("ауд. часов в год", typeof(int));
            dataTable.Columns.Add("ауд. часов в семестре", typeof(int));
            dataTable.Columns.Add("всего", typeof(int));
            dataTable.Columns.Add("лекции", typeof(int));
            dataTable.Columns.Add("Семинары и практ. занятия", typeof(string));
            dataTable.Columns.Add("Форма аттестации", typeof(string));
            dataTable.Columns.Add("Курсовая работа (* - по выбору)", typeof(string));
        }

        private void BtnPreview_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Функция предпросмотра будет реализована позже");
        }

        private void BtnFillData_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                openFileDialog.Title = "Выберите файл с данными";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    LoadFromFile(openFileDialog.FileName);
                    MessageBox.Show("Данные успешно загружены!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void BtnLoadTemplate_Click(object sender, EventArgs e)
        {
            try
            {
                string templatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "template.txt");

                if (!File.Exists(templatePath))
                {
                    MessageBox.Show("Файл шаблона (template.txt) не найден!");
                    return;
                }

                LoadFromFile(templatePath);
                MessageBox.Show("Шаблон успешно загружен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке шаблона: {ex.Message}");
            }
        }

        private void LoadFromFile(string filePath)
        {
            string[] lines = File.ReadAllLines(filePath);
            dataTable.Rows.Clear();

            foreach (string line in lines)
            {
                if (!string.IsNullOrWhiteSpace(line))
                {
                    string[] item = line.Split(';');
                    DataRow newRow = dataTable.NewRow();

                    for (int i = 0; i < item.Length && i < dataTable.Columns.Count; i++)
                    {
                        newRow[i] = string.IsNullOrEmpty(item[i]) ? DBNull.Value : (object)item[i];
                    }

                    dataTable.Rows.Add(newRow);
                }
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            if (dataTable.Rows.Count == 0)
            {
                MessageBox.Show("Сначала загрузите данные!");
                return;
            }

            try
            {
                ExportToExcel();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void ExportToExcel()
        {
            E.Application excelApp = null;
            E.Workbook workbook = null;
            E.Worksheet worksheet = null;

            try
            {
                excelApp = new E.Application();
                workbook = excelApp.Workbooks.Add();
                worksheet = workbook.ActiveSheet;

                excelApp.Visible = true;

                // Создаем трёхуровневую шапку
                CreateThreeLevelHeader(worksheet);

                // Данные таблицы (начинаем с 4 строки, так как шапка занимает 3 строки)
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    for (int j = 0; j < dataTable.Columns.Count; j++)
                    {
                        var cellValue = dataTable.Rows[i][j];

                        E.Range cell = worksheet.Cells[i + 4, j + 1];
                        worksheet.Cells[i + 4, j + 1] = cellValue == DBNull.Value ? "" : cellValue.ToString();

                        // Выравнивание для числовых колонок
                        if (j >= 2 && j <= 6 && cellValue != DBNull.Value)
                        {
                            worksheet.Cells[i + 4, j + 1].NumberFormat = "0";
                            worksheet.Cells[i + 4, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignRight;
                        }
                        else
                        {
                            worksheet.Cells[i + 4, j + 1].HorizontalAlignment = E.XlHAlign.xlHAlignLeft;
                        }

                        worksheet.Cells[i + 4, j + 1].WrapText = true;

                        

                        cell.Borders.LineStyle = E.XlLineStyle.xlContinuous;

                        // Границы для всех ячеек
                        worksheet.Cells[i + 4, j + 1].Borders.LineStyle = E.XlLineStyle.xlContinuous;

                        // Стиль для строки "ИТОГО"
                        if (dataTable.Rows[i]["Наименование дисциплин"].ToString() == "ИТОГО:")
                        {
                            worksheet.Cells[i + 4, j + 1].Font.Bold = true;
                            worksheet.Cells[i + 4, j + 1].Interior.Color =
                                System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                        }
                    }
                }



                // Настройка высоты строк
                worksheet.Rows[1].RowHeight = 20;
                worksheet.Rows[2].RowHeight = 20;
                worksheet.Rows[3].RowHeight = 25;
                for (int i = 4; i <= dataTable.Rows.Count + 3; i++)
                {
                    worksheet.Rows[i].RowHeight = 20;
                }

                // 1. Центрируем диапазон C4:K6
                E.Range centerRange = worksheet.Range["C4:K6"];
                centerRange.HorizontalAlignment = E.XlHAlign.xlHAlignCenter;
                centerRange.VerticalAlignment = E.XlVAlign.xlVAlignCenter;

                // Последняя строка (строка с ИТОГО)
                int lastRow = dataTable.Rows.Count + 3;
                E.Range lastRowRange = worksheet.Rows[lastRow];

                // форматирование
                lastRowRange.RowHeight = 27.75; // увеличиваем высоту
                lastRowRange.Font.Bold = true; // жирный текст
                lastRowRange.HorizontalAlignment = E.XlHAlign.xlHAlignCenter; // по центру
                lastRowRange.VerticalAlignment = E.XlVAlign.xlVAlignCenter;

                // Сохранение файла - пользователь выбирает место
                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel Files (*.xlsx)|*.xlsx|All Files (*.*)|*.*";
                saveDialog.FileName = "Учебный_план.xlsx";
                saveDialog.Title = "Выберите место для сохранения файла";

                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveDialog.FileName);
                    MessageBox.Show($"Таблица успешно экспортирована в:\n{saveDialog.FileName}", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            finally
            {
                // Освобождение ресурсов
                if (workbook != null)
                {
                    workbook.Close(false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                }
                if (excelApp != null)
                {
                    excelApp.Quit();
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }
                if (worksheet != null)
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                }
            }
        }

        private void CreateThreeLevelHeader(E.Worksheet worksheet)
        {
            // Настройка ширины колонок
            worksheet.Columns[1].ColumnWidth = 8;    // № п/п
            worksheet.Columns[2].ColumnWidth = 40;   // Наименование дисциплин
            worksheet.Columns[3].ColumnWidth = 14;   // всего часов в год
            worksheet.Columns[4].ColumnWidth = 22;   // переаттестация часов
            worksheet.Columns[5].ColumnWidth = 14;   // аул. часов в год
            worksheet.Columns[6].ColumnWidth = 14;   // аул. часов в семестре
            worksheet.Columns[7].ColumnWidth = 14;   // аул. часы в неделю
            worksheet.Columns[8].ColumnWidth = 12;   // лекцион секционных проект, газетные
            worksheet.Columns[9].ColumnWidth = 12;   // Форма аттестации
            worksheet.Columns[10].ColumnWidth = 16;
            worksheet.Columns[11].ColumnWidth = 16;

            // Первый уровень шапки (объединенные ячейки)
            worksheet.Cells[1, 1] = "№ п/п";
            worksheet.Cells[1, 2] = "Наименование дисциплин";
            worksheet.Cells[1, 3] = "Всего часов в год";
            worksheet.Cells[1, 4] = "Перетестация часов по нормативн. учебн. плану";
            worksheet.Cells[1, 5] = "Ауд. часов в  год";
            worksheet.Cells[1, 6] = "5 семестр (18 недель)";
            

            // Объединение ячеек первого уровня
            worksheet.Range["A1:A3"].Merge(); // № п/п
            worksheet.Range["B1:B3"].Merge(); // Наименование дисциплин
            worksheet.Range["C1:C3"].Merge(); // Всего часов
            worksheet.Range["D1:D3"].Merge(); // Перетестация
            worksheet.Range["E1:E3"].Merge(); // Аудиторные часы в год
            worksheet.Range["F1:K1"].Merge(); // 5 семестр

            // Второй уровень шапки (только для аудиторных занятий)
            worksheet.Cells[2, 6] = "ауд. часы в семестре";
            worksheet.Cells[2, 7] = "ауд. часы в неделю";
            worksheet.Cells[2, 10] = "Форма аттестации";
            worksheet.Cells[2, 11] = "Курсовая работа (* по выбору)";

            // Объединение ячеек второго уровня
            worksheet.Range["F2:F3"].Merge(); // ауд. часы в семестре
            worksheet.Range["G2:I2"].Merge(); // ауд. часы в неделю
            worksheet.Range["J2:J3"].Merge(); // форма аттестации
            worksheet.Range["K2:K3"].Merge(); // курсовая работа

            // Третий уровень шапки (детальные заголовки)
            worksheet.Cells[3, 7] = "всего";
            worksheet.Cells[3, 8] = "лекции";
            worksheet.Cells[3, 9] = "Семинары и практ. занятия";

            E.Range headerRange = worksheet.Range["A1:K3"];
            headerRange.Font.Bold = true;
            headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
            headerRange.HorizontalAlignment = E.XlHAlign.xlHAlignCenter;
            headerRange.VerticalAlignment = E.XlVAlign.xlVAlignCenter;
            headerRange.Borders.LineStyle = E.XlLineStyle.xlContinuous;
            headerRange.WrapText = true;
        }
    }
}
