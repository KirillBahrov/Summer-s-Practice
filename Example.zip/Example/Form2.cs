﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Example
{
    public partial class Form2 : Form
    {
        private string currentFilePath = string.Empty;
        private string citiesFilePath = "cities.txt";

        public Form2()
        {
            InitializeComponent();
            LoadCities();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Word Documents|*.docx";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    currentFilePath = sfd.FileName;
                    GenerateDocument(currentFilePath);
                    MessageBox.Show("Файл создан!");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                MessageBox.Show("Сначала создайте файл!");
                return;
            }

            GenerateDocument(currentFilePath);
            MessageBox.Show("Данные сохранены!");
        }

        private void LoadCities()
        {
            try
            {
                if (File.Exists(citiesFilePath))
                {
                    var cities = File.ReadAllLines(citiesFilePath)
                        .Where(line => !string.IsNullOrWhiteSpace(line))
                        .Select(line => line.Trim())
                        .Distinct()
                        .OrderBy(city => city)
                        .ToArray();

                    comboBox4.Items.Clear();
                    comboBox4.Items.AddRange(cities);

                    if (comboBox4.Items.Count > 0)
                    {
                        comboBox4.SelectedIndex = 0;
                    }
                }
                else
                {
                    // Создаем файл с городами по умолчанию, если он не существует
                    var defaultCities = new[]
                    {
                        "Москва",
                        "Санкт-Петербург",
                        "Новосибирск",
                        "Екатеринбург",
                        "Казань"
                    };

                    File.WriteAllLines(citiesFilePath, defaultCities);
                    comboBox4.Items.AddRange(defaultCities);
                    comboBox4.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки списка городов: {ex.Message}");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string newCity = comboBox4.Text.Trim();

            if (string.IsNullOrWhiteSpace(newCity))
            {
                MessageBox.Show("Введите название города!");
                return;
            }

            try
            {
                // Проверяем, есть ли город уже в списке
                bool cityExists = false;
                foreach (var item in comboBox4.Items)
                {
                    if (item.ToString().Equals(newCity, StringComparison.OrdinalIgnoreCase))
                    {
                        cityExists = true;
                        break;
                    }
                }

                if (!cityExists)
                {
                    // Добавляем город в файл
                    using (StreamWriter sw = File.AppendText(citiesFilePath))
                    {
                        sw.WriteLine(newCity);
                    }

                    // Перезагружаем список городов
                    LoadCities();

                    // Выбираем добавленный город
                    comboBox4.SelectedItem = newCity;

                    MessageBox.Show($"Город \"{newCity}\" успешно добавлен!");
                }
                else
                {
                    MessageBox.Show("Этот город уже есть в списке!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления города: {ex.Message}");
            }
        }

        private void GenerateDocument(string filePath)
        {
            try
            {
                using (WordprocessingDocument doc = WordprocessingDocument.Create(
                    filePath, DocumentFormat.OpenXml.WordprocessingDocumentType.Document))
                {
                    MainDocumentPart mainPart = doc.AddMainDocumentPart();
                    mainPart.Document = new Document();
                    Body body = new Body();

                    // Устанавливаем шрифт по умолчанию
                    SetDefaultFont(mainPart);

                    // Добавление содержимого документа
                    AddTitleContent(body);

                    mainPart.Document.Append(body);
                    mainPart.Document.Save();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void AddParagraph(Body body, string text, int fontSize, JustificationValues alignment, bool isBold)
        {
            Paragraph paragraph = new Paragraph();
            Run run = new Run();
            RunProperties runProperties = new RunProperties();
            FontSize fontsize = new FontSize() { Val = (fontSize * 2).ToString() };

            runProperties.Append(fontsize);

            if (isBold)
            {
                runProperties.Bold = new Bold();
            }

            run.RunProperties = runProperties;
            run.Append(new Text(text));

            ParagraphProperties paragraphProperties = new ParagraphProperties();
            paragraphProperties.Justification = new Justification() { Val = alignment };

            paragraph.ParagraphProperties = paragraphProperties;
            paragraph.Append(run);
            body.Append(paragraph);
        }

        private void AddHorizontalLine(Body body)
        {
            Paragraph paragraph = new Paragraph();
            Run run = new Run();

            for (int i = 0; i < 13; i++)
            {
                Run tabRun = new Run(
                    new TabChar(),
                    new Text(" ")
                );
                tabRun.RunProperties = new RunProperties(
                    new Underline() { Val = UnderlineValues.Single },
                    new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" });
                run.Append(tabRun);
            }

            paragraph.Append(run);
            body.Append(paragraph);
        }

        private void AddTitleContent(Body body)
        {
            // Создание различных параграфов с текстом
            AddParagraph(body, "МИНИСТЕРСТВО ТРАНСПОРТА РОССИЙСКОЙ ФЕДЕРАЦИИ", 14, JustificationValues.Center, true);
            AddParagraph(body, "ФЕДЕРАЛЬНОЕ ГОСУДАРСТВЕННОЕ АВТОНОМНОЕ", 14, JustificationValues.Center, false);
            AddParagraph(body, "ОБРАЗОВАТЕЛЬНОЕ УЧРЕЖДЕНИЕ ВЫСШЕГО ОБРАЗОВАНИЯ", 14, JustificationValues.Center, false);
            AddParagraph(body, "«РОССИЙСКИЙ УНИВЕРСИТЕТ ТРАНСПОРТА» (РУТ (МИИТ))", 14, JustificationValues.Center, true);
            AddParagraph(body, "ИНСТИТУТ ТРАНСПОРТНОЙ ТЕХНИКИ И СИСТЕМ УПРАВЛЕНИЯ", 14, JustificationValues.Center, true);

            // Добавление линии с помощью TabChar
            AddHorizontalLine(body);

            AddParagraph(body, "Кафедра «Управление и защита информации»", 14, JustificationValues.Center, false);
            AddParagraph(body, comboBox1.Text, 16, JustificationValues.Center, false);
            AddParagraph(body, comboBox2.Text, 14, JustificationValues.Center, false);
            AddParagraph(body, $"Задание {comboBox3.Text}", 14, JustificationValues.Center, true);
            AddParagraph(body, "по дисциплине", 14, JustificationValues.Center, false);
            AddParagraph(body, textBox5.Text, 14, JustificationValues.Center, true);
            AddParagraph(body, $"Тема: {textBox4.Text}", 14, JustificationValues.Center, false);
            AddParagraph(body, $"Вариант № {textBox3.Text}", 14, JustificationValues.Center, true);

            // Пустой параграф для отступа
            AddParagraph(body, "", 14, JustificationValues.Left, false);

            // Добавление нижней части с выравниванием по правому краю
            AddParagraph(body, $"Выполнил: ст. гр.", 14, JustificationValues.Right, false);
            AddParagraph(body, $"{textBox6.Text}, {textBox1.Text}", 14, JustificationValues.Right, false);
            AddParagraph(body, $"Проверил: {textBox2.Text}", 14, JustificationValues.Right, false);

            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, "", 14, JustificationValues.Left, false);
            AddParagraph(body, $"{comboBox4.Text} 2025 г.", 14, JustificationValues.Center, false);
        }

        private void SetDefaultFont(MainDocumentPart mainPart)
        {
            try
            {
                // Создаем свойства документа
                DocDefaults docDefaults = new DocDefaults();

                // Устанавливаем свойства для обычного текста
                RunPropertiesDefault runPropertiesDefault = new RunPropertiesDefault();
                RunPropertiesBaseStyle runPropertiesBaseStyle = new RunPropertiesBaseStyle();
                runPropertiesBaseStyle.Append(new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" });
                runPropertiesDefault.Append(runPropertiesBaseStyle);
                docDefaults.Append(runPropertiesDefault);

                // Устанавливаем одинарный межстрочный интервал
                ParagraphPropertiesDefault paragraphPropertiesDefault = new ParagraphPropertiesDefault();
                ParagraphPropertiesBaseStyle paragraphPropertiesBaseStyle = new ParagraphPropertiesBaseStyle();
                SpacingBetweenLines spacing = new SpacingBetweenLines() { Line = "240", LineRule = LineSpacingRuleValues.Auto };
                paragraphPropertiesBaseStyle.Append(spacing);
                paragraphPropertiesDefault.Append(paragraphPropertiesBaseStyle);
                docDefaults.Append(paragraphPropertiesDefault);

                // Добавляем настройки по умолчанию в документ
                StyleDefinitionsPart stylePart = mainPart.AddNewPart<StyleDefinitionsPart>();
                stylePart.Styles = new Styles();
                stylePart.Styles.Append(docDefaults);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка установки шрифта: {ex.Message}");
            }
        }
    }
}
