﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Example
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog()
            {
                Filter = "Word Documents (*.docx)|*.docx",
                FileName = "Анкета.docx"
            })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    CreateQuestionnaire(sfd.FileName);
                    MessageBox.Show("Анкета успешно создана!");
                }
            }
        }

        private void CreateQuestionnaire(string filePath)
        {
            using (WordprocessingDocument doc = WordprocessingDocument.Create(
                filePath,
                WordprocessingDocumentType.Document))
            {
                MainDocumentPart mainPart = doc.AddMainDocumentPart();
                mainPart.Document = new Document();
                Body body = new Body();

                // Устанавливаем шрифт Times New Roman для всего документа
                SetDefaultFont(mainPart);

                // Создаем таблицу для верхней части (распоряжение и место для фото)
                Table headerTable = CreateHeaderTable();
                body.AppendChild(headerTable);

                // Заголовок анкеты
                body.AppendChild(CreateParagraph("", false, JustificationValues.Center));
                body.AppendChild(CreateParagraph("А Н К Е Т А", true, JustificationValues.Center));
                body.AppendChild(CreateParagraph("", false, JustificationValues.Center)); // Пустая строка

                // Создаем таблицу для первого пункта (ФИО + фото)
                Table firstQuestionTable = new Table();
                TableProperties tableProperties = new TableProperties(
                    new TableBorders(
                        new TopBorder() { Val = BorderValues.None },
                        new BottomBorder() { Val = BorderValues.None },
                        new LeftBorder() { Val = BorderValues.None },
                        new RightBorder() { Val = BorderValues.None },
                        new InsideHorizontalBorder() { Val = BorderValues.None },
                        new InsideVerticalBorder() { Val = BorderValues.None }
                    )
                );
                firstQuestionTable.AppendChild(tableProperties);

                TableRow row = new TableRow();

                // Левая ячейка - ФИО
                TableCell leftCell = new TableCell();

                leftCell.Append(new Paragraph(new Run(new Break())));

                // Пункт 1. Фамилия
                Paragraph surnameParagraph = new Paragraph(
                    new Run(
                        new Text("1. Фамилия")
                    )
                    {
                        RunProperties = new RunProperties(
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    },
                    new Run(
                        new TabChar()
                        ),
                    new Run(
                        new Text("________________________________________________")
                    )
                    {
                        RunProperties = new RunProperties(
                            new Underline() { Val = UnderlineValues.Single },
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    }
                );
                leftCell.Append(surnameParagraph);

                // Имя
                Paragraph nameParagraph = new Paragraph(
                    new Run(
                        new Text("Имя")
                    )
                    {
                        RunProperties = new RunProperties(
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    },
                    new Run(
                        new TabChar()
                        ),
                    new Run(
                        new TabChar()
                        ),
                    new Run(
                        new Text("________________________________________________")
                    )
                    {
                        RunProperties = new RunProperties(
                            new Underline() { Val = UnderlineValues.Single },
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    }
                );
                leftCell.Append(nameParagraph);

                // Отчество
                Paragraph patronymicParagraph = new Paragraph(
                    new Run(
                        new Text("Отчество")
                    )
                    {
                        RunProperties = new RunProperties(
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    },
                    new Run(
                        new TabChar()
                        ),
                    new Run(
                        new Text("________________________________________________")
                    )
                    {
                        RunProperties = new RunProperties(
                            new Underline() { Val = UnderlineValues.Single },
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    }
                );
                leftCell.Append(patronymicParagraph);

                leftCell.TableCellProperties = new TableCellProperties(
                    new TableCellWidth() { Width = "8000", Type = TableWidthUnitValues.Dxa }
                );

                // Правая ячейка - место для фотографии
                TableCell rightCell = new TableCell();
                Paragraph photoParagraph = new Paragraph(
                    new Run(
                        new Text("Место для фотографии")
                    )
                    {
                        RunProperties = new RunProperties(
                            new Italic(),
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    }
                );
                photoParagraph.ParagraphProperties = new ParagraphProperties(
                    new Justification() { Val = JustificationValues.Center }
                );
                rightCell.Append(photoParagraph);

                // Рамка вокруг места для фото
                rightCell.TableCellProperties = new TableCellProperties(
                    new TableCellBorders(
                        new TopBorder() { Val = BorderValues.Single, Size = 4 },
                        new BottomBorder() { Val = BorderValues.Single, Size = 4 },
                        new LeftBorder() { Val = BorderValues.Single, Size = 4 },
                        new RightBorder() { Val = BorderValues.Single, Size = 4 }
                    ),
                    new TableCellWidth() { Width = "2000", Type = TableWidthUnitValues.Dxa },
                    new TableCellVerticalAlignment() { Val = TableVerticalAlignmentValues.Center }
                );

                row.Append(leftCell, rightCell);
                firstQuestionTable.Append(row);
                body.AppendChild(firstQuestionTable);
                body.AppendChild(CreateParagraph("", false, JustificationValues.Center));

                Table questionTable = CreateQuestionTable();
                body.AppendChild(questionTable);

                mainPart.Document.Append(body);
                mainPart.Document.Save();
            }
        }

        private Table CreateHeaderTable()
        {
            Table table = new Table();

            // Свойства таблицы
            TableProperties tableProperties = new TableProperties(
                new TableBorders(
                    new TopBorder() { Val = BorderValues.None },
                    new BottomBorder() { Val = BorderValues.None },
                    new LeftBorder() { Val = BorderValues.None },
                    new RightBorder() { Val = BorderValues.None },
                    new InsideHorizontalBorder() { Val = BorderValues.None },
                    new InsideVerticalBorder() { Val = BorderValues.None }
                ),
                new TableWidth() { Width = "2000", Type = TableWidthUnitValues.Dxa }, // Ширина таблицы
                new TableJustification() { Val = TableRowAlignmentValues.Right } // Выравнивание таблицы по правому краю
            );
            table.AppendChild(tableProperties);

            // Первая строка таблицы
            TableRow row1 = new TableRow();

            // Ячейка с текстом распоряжения (правая часть)
            TableCell cell1 = new TableCell(new Paragraph(
                new Run(
                    new Text("Утверждена распоряжением" +
                    "\r\nПравительства Российской" +
                    "\r\nФедерации от 26 мая 2005 г." +
                    "\r\n№ 667-р (в редакции от 5" +
                    "\r\nмарта 2018 г.)")
                )
                {
                    RunProperties = new RunProperties(
                        new FontSize() { Val = "16" },
                        new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                }
            ));

            // Свойства ячейки - выравнивание по правому краю
            cell1.TableCellProperties = new TableCellProperties(
                new TableCellWidth() { Width = "4000", Type = TableWidthUnitValues.Dxa },
                new TableCellVerticalAlignment() { Val = TableVerticalAlignmentValues.Center }
            );

            row1.Append(cell1); // Сначала пустая ячейка, потом с текстом
            table.Append(row1);

            return table;
        }

        private Table CreateQuestionTable()
        {
            // СОЗДАЕМ ТАБЛИЦУ ДЛЯ ОСТАЛЬНЫХ ПУНКТОВ (2x6)
            Table questionsTable = new Table();
            TableProperties questionsTableProperties = new TableProperties(
                new TableBorders(
                    new TopBorder() { Val = BorderValues.BasicThinLines },
                    new BottomBorder() { Val = BorderValues.BasicThinLines },
                    new LeftBorder() { Val = BorderValues.None }, // Убираем левую границу
                    new RightBorder() { Val = BorderValues.None }, // Убираем правую границу
                    new InsideHorizontalBorder() { Val = BorderValues.BasicThinLines },
                    new InsideVerticalBorder() { Val = BorderValues.BasicThinLines }
                ),
                new TableCellWidth() { Width = "10000" }
            );
            questionsTable.AppendChild(questionsTableProperties);

            // Данные для таблицы
            var questions = new[]
            {
                "2. Если изменяли фамилию, имя или отчество, то укажите их, а также когда, где и по какой причине изменяли.",
                "3. Число, месяц, год и место рождения (село, деревня, город, район, область, край, республика, страна).",
                "4. Гражданство (если изменяли, то укажите, когда и по какой причине, если имеете гражданство другого государства – укажите).",
                "5. Образование (когда и какие учебные заведения окончили, номера дипломов). Направление подготовки или специальность по диплому. Квалификация по диплому.",
                "6. Послевузовское профессиональное образование: адъюнктура, докторантура (наименование образовательного или научного учреждения, год окончания). Ученая степень, ученое звание (когда присвоены, номера дипломов, аттестатов).",
                "7. Какими иностранными языками и языками народов Российской Федерации владеете и в какой степени (читаете и переводите со словарем, читаете и можете объясняться, владеете свободно)."
            };

            // Создаем строки таблицы
            foreach (var question in questions)
            {
                TableRow questionRow = new TableRow();

                // Левая ячейка с номером и текстом вопроса
                TableCell questionCell = new TableCell();
                Paragraph questionParagraph = new Paragraph(
                    new Run(
                        new Text(question)
                    )
                    {
                        RunProperties = new RunProperties(
                            new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                    }
                );
                questionCell.Append(questionParagraph);
                questionCell.TableCellProperties = new TableCellProperties(
                    new TableCellWidth() { Width = "5000", Type = TableWidthUnitValues.Dxa } // 50% ширины
                );

                // Правая ячейка (пустая)
                TableCell emptyCell = new TableCell();
                emptyCell.Append(new Paragraph(new Run(new Text(""))));
                emptyCell.TableCellProperties = new TableCellProperties(
                    new TableCellWidth() { Width = "5000", Type = TableWidthUnitValues.Dxa } // 50% ширины
                );

                questionRow.Append(questionCell, emptyCell);
                questionsTable.Append(questionRow);
            }

            return questionsTable;
        }

        // Метод для установки шрифта Times New Roman по умолчанию
        private void SetDefaultFont(MainDocumentPart mainPart)
        {
            DocDefaults docDefaults = new DocDefaults();

            RunPropertiesDefault runPropertiesDefault = new RunPropertiesDefault();
            RunPropertiesBaseStyle runPropertiesBaseStyle = new RunPropertiesBaseStyle();
            runPropertiesBaseStyle.Append(new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" });
            runPropertiesDefault.Append(runPropertiesBaseStyle);
            docDefaults.Append(runPropertiesDefault);
        }

        private Paragraph CreateParagraph(string text, bool bold, JustificationValues align)
        {
            Paragraph paragraph = new Paragraph(
                new Run(
                    new Text(text)
                    {
                        Space = SpaceProcessingModeValues.Preserve
                    }
                )
                {
                    RunProperties = new RunProperties(
                        new Bold() { Val = bold },
                        new RunFonts() { Ascii = "Times New Roman", HighAnsi = "Times New Roman" })
                }
            );

            paragraph.ParagraphProperties = new ParagraphProperties(
                new Justification() { Val = align });

            return paragraph;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
