﻿namespace PracticeWord
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnGenerateAnketa = new System.Windows.Forms.Button();
            this.btnGenerateTitle = new System.Windows.Forms.Button();
            this.btnUpdateCities = new System.Windows.Forms.Button();

            this.txtFIO = new System.Windows.Forms.TextBox();
            this.txtBirthDate = new System.Windows.Forms.TextBox();
            this.cmbBirthPlace = new System.Windows.Forms.ComboBox();
            this.txtEducation = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtWorkPlace = new System.Windows.Forms.TextBox();

            this.txtVariant = new System.Windows.Forms.TextBox();
            this.txtGroup = new System.Windows.Forms.TextBox();
            this.txtStudent = new System.Windows.Forms.TextBox();
            this.txtChecker = new System.Windows.Forms.TextBox();
            this.txtCityYear = new System.Windows.Forms.TextBox();

            this.lblFIO = new System.Windows.Forms.Label();
            this.lblBirthDate = new System.Windows.Forms.Label();
            this.lblBirthPlace = new System.Windows.Forms.Label();
            this.lblEducation = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblWorkPlace = new System.Windows.Forms.Label();

            this.lblVariant = new System.Windows.Forms.Label();
            this.lblGroup = new System.Windows.Forms.Label();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblChecker = new System.Windows.Forms.Label();
            this.lblCityYear = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // === Левая колонка (Анкета) ===
            int leftX = 20;
            int leftWidth = 250;

            this.lblFIO.Location = new System.Drawing.Point(leftX, 20);
            this.lblFIO.Text = "ФИО:";
            this.txtFIO.Location = new System.Drawing.Point(leftX + 120, 20);
            this.txtFIO.Width = leftWidth;

            this.lblBirthDate.Location = new System.Drawing.Point(leftX, 50);
            this.lblBirthDate.Text = "Дата рождения:";
            this.txtBirthDate.Location = new System.Drawing.Point(leftX + 120, 50);
            this.txtBirthDate.Width = 120;

            this.lblBirthPlace.Location = new System.Drawing.Point(leftX, 80);
            this.lblBirthPlace.Text = "Город рождения:";
            this.cmbBirthPlace.Location = new System.Drawing.Point(leftX + 120, 80);
            this.cmbBirthPlace.Width = 150;

            this.btnUpdateCities.Location = new System.Drawing.Point(leftX + 280, 80);
            this.btnUpdateCities.Name = "btnUpdateCities";
            this.btnUpdateCities.Size = new System.Drawing.Size(100, 23);
            this.btnUpdateCities.Text = "Обновить";
            this.btnUpdateCities.UseVisualStyleBackColor = true;
            this.btnUpdateCities.Click += new System.EventHandler(this.btnUpdateCities_Click);

            this.lblEducation.Location = new System.Drawing.Point(leftX, 110);
            this.lblEducation.Text = "Образование:";
            this.txtEducation.Location = new System.Drawing.Point(leftX + 120, 110);
            this.txtEducation.Width = leftWidth;

            this.lblAddress.Location = new System.Drawing.Point(leftX, 140);
            this.lblAddress.Text = "Адрес:";
            this.txtAddress.Location = new System.Drawing.Point(leftX + 120, 140);
            this.txtAddress.Width = leftWidth;

            this.lblPhone.Location = new System.Drawing.Point(leftX, 170);
            this.lblPhone.Text = "Телефон:";
            this.txtPhone.Location = new System.Drawing.Point(leftX + 120, 170);
            this.txtPhone.Width = leftWidth;

            this.lblWorkPlace.Location = new System.Drawing.Point(leftX, 200);
            this.lblWorkPlace.Text = "Место работы/учёбы:";
            this.txtWorkPlace.Location = new System.Drawing.Point(leftX + 150, 200);
            this.txtWorkPlace.Width = 220;

            // === Правая колонка (Титульный лист) ===
            int rightX = 420;
            int rightWidth = 200;

            this.lblVariant.Location = new System.Drawing.Point(rightX, 20);
            this.lblVariant.Text = "Вариант:";
            this.txtVariant.Location = new System.Drawing.Point(rightX + 100, 20);
            this.txtVariant.Width = 80;

            this.lblGroup.Location = new System.Drawing.Point(rightX, 50);
            this.lblGroup.Text = "Группа:";
            this.txtGroup.Location = new System.Drawing.Point(rightX + 100, 50);
            this.txtGroup.Width = 80;

            this.lblStudent.Location = new System.Drawing.Point(rightX, 80);
            this.lblStudent.Text = "Студент:";
            this.txtStudent.Location = new System.Drawing.Point(rightX + 100, 80);
            this.txtStudent.Width = rightWidth;

            this.lblChecker.Location = new System.Drawing.Point(rightX, 110);
            this.lblChecker.Text = "Проверяющий:";
            this.txtChecker.Location = new System.Drawing.Point(rightX + 100, 110);
            this.txtChecker.Width = rightWidth;

            this.lblCityYear.Location = new System.Drawing.Point(rightX, 140);
            this.lblCityYear.Text = "Город, год:";
            this.txtCityYear.Location = new System.Drawing.Point(rightX + 100, 140);
            this.txtCityYear.Width = 100;

            // === Кнопки ===
            this.btnGenerateAnketa.Location = new System.Drawing.Point(20, 260);
            this.btnGenerateAnketa.Name = "btnGenerateAnketa";
            this.btnGenerateAnketa.Size = new System.Drawing.Size(200, 30);
            this.btnGenerateAnketa.Text = "Сформировать анкету";
            this.btnGenerateAnketa.UseVisualStyleBackColor = true;
            this.btnGenerateAnketa.Click += new System.EventHandler(this.btnGenerateAnketa_Click);

            this.btnGenerateTitle.Location = new System.Drawing.Point(240, 260);
            this.btnGenerateTitle.Name = "btnGenerateTitle";
            this.btnGenerateTitle.Size = new System.Drawing.Size(220, 30);
            this.btnGenerateTitle.Text = "Сформировать титульный лист";
            this.btnGenerateTitle.UseVisualStyleBackColor = true;
            this.btnGenerateTitle.Click += new System.EventHandler(this.btnGenerateTitle_Click);

            // === Добавление на форму ===
            this.Controls.Add(this.btnGenerateAnketa);
            this.Controls.Add(this.btnGenerateTitle);
            this.Controls.Add(this.btnUpdateCities);

            this.Controls.Add(this.lblFIO);
            this.Controls.Add(this.txtFIO);
            this.Controls.Add(this.lblBirthDate);
            this.Controls.Add(this.txtBirthDate);
            this.Controls.Add(this.lblBirthPlace);
            this.Controls.Add(this.cmbBirthPlace);
            this.Controls.Add(this.lblEducation);
            this.Controls.Add(this.txtEducation);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.lblWorkPlace);
            this.Controls.Add(this.txtWorkPlace);

            this.Controls.Add(this.lblVariant);
            this.Controls.Add(this.txtVariant);
            this.Controls.Add(this.lblGroup);
            this.Controls.Add(this.txtGroup);
            this.Controls.Add(this.lblStudent);
            this.Controls.Add(this.txtStudent);
            this.Controls.Add(this.lblChecker);
            this.Controls.Add(this.txtChecker);
            this.Controls.Add(this.lblCityYear);
            this.Controls.Add(this.txtCityYear);

            // === Настройки формы ===
            this.Text = "Генератор документов";
            this.ClientSize = new System.Drawing.Size(700, 320);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button btnGenerateAnketa;
        private System.Windows.Forms.Button btnGenerateTitle;
        private System.Windows.Forms.Button btnUpdateCities;

        private System.Windows.Forms.TextBox txtFIO;
        private System.Windows.Forms.TextBox txtBirthDate;
        private System.Windows.Forms.ComboBox cmbBirthPlace;
        private System.Windows.Forms.TextBox txtEducation;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtWorkPlace;

        private System.Windows.Forms.TextBox txtVariant;
        private System.Windows.Forms.TextBox txtGroup;
        private System.Windows.Forms.TextBox txtStudent;
        private System.Windows.Forms.TextBox txtChecker;
        private System.Windows.Forms.TextBox txtCityYear;

        private System.Windows.Forms.Label lblFIO;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.Label lblBirthPlace;
        private System.Windows.Forms.Label lblEducation;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblWorkPlace;

        private System.Windows.Forms.Label lblVariant;
        private System.Windows.Forms.Label lblGroup;
        private System.Windows.Forms.Label lblStudent;
        private System.Windows.Forms.Label lblChecker;
        private System.Windows.Forms.Label lblCityYear;
    }
}
