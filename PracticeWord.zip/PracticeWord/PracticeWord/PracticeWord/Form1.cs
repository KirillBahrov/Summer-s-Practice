﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace PracticeWord
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadCities();
        }

        private void LoadCities()
        {
            try
            {
                if (File.Exists("cities.txt"))
                {
                    var cities = File.ReadAllLines("cities.txt").Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();
                    cmbBirthPlace.Items.Clear();
                    cmbBirthPlace.Items.AddRange(cities);
                    if (cities.Length > 0) cmbBirthPlace.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки городов: " + ex.Message);
            }
        }

        private void btnUpdateCities_Click(object sender, EventArgs e)
        {
            LoadCities();
        }

        private void btnGenerateAnketa_Click(object sender, EventArgs e)
        {
            GenerateAnketa();
        }

        private void btnGenerateTitle_Click(object sender, EventArgs e)
        {
            GenerateTitlePage();
        }

        private void GenerateAnketa()
        {
            try
            {
                var wordApp = new Word.Application();
                var doc = wordApp.Documents.Add();
                wordApp.Visible = true;

                doc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;
                doc.PageSetup.TopMargin = 50;
                doc.PageSetup.BottomMargin = 50;
                doc.PageSetup.LeftMargin = 50;
                doc.PageSetup.RightMargin = 50;

                // Заголовок в правом верхнем углу
                Word.Paragraph header = doc.Content.Paragraphs.Add();
                header.Range.Text =
                    "Утверждена распоряжением Правительства\n" +
                    "Российской Федерации\n" +
                    "от 26 мая 2005 г. № 667-р\n" +
                    "(в ред. от 5 марта 2018 г.)";
                header.Range.Font.Size = 10;
                header.Range.Font.Name = "Times New Roman";
                header.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                header.Range.InsertParagraphAfter();

                // АНКЕТА
                Word.Paragraph title = doc.Content.Paragraphs.Add();
                title.Range.Text = "А Н К Е Т А";
                title.Range.Font.Size = 14;
                title.Range.Font.Name = "Times New Roman";
                title.Range.Bold = 1;
                title.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                title.SpaceAfter = 20;
                title.Range.InsertParagraphAfter();

                // Таблица анкеты
                Word.Table table = doc.Tables.Add(doc.Range(doc.Content.End - 1, doc.Content.End), 8, 2);
                table.Borders.Enable = 1;
                table.Range.Font.Name = "Times New Roman";
                table.Range.Font.Size = 12;
                table.Columns[1].Width = 300;
                table.Columns[2].Width = 250;

                // Первая строка (ФИО + фото)
                table.Cell(1, 1).Range.Text =
                    "1. Фамилия ___________________________\n" +
                    "Имя _________________________________\n" +
                    "Отчество ____________________________";

                table.Cell(1, 2).Range.Text = "Место для фотографии";
                table.Cell(1, 2).Range.ParagraphFormat.Alignment =
                    Word.WdParagraphAlignment.wdAlignParagraphCenter;
                table.Cell(1, 2).VerticalAlignment =
                    Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

                // Остальные пункты
                table.Cell(2, 1).Range.Text = "2. Если изменяли фамилию, имя или отчество, то укажите их, а также когда, где и по какой причине изменяли";
                table.Cell(3, 1).Range.Text = "3. Число, месяц, год и место рождения (село, деревня, город, район, область, край, республика, страна)";
                table.Cell(3, 2).Range.Text = $"{txtBirthDate.Text}, {cmbBirthPlace.Text}";
                table.Cell(4, 1).Range.Text = "4. Гражданство (если изменяли, то укажите, когда и по какой причине, если имеете гражданство другого государства — укажите)";
                table.Cell(5, 1).Range.Text = "5. Образование (когда и какие учебные заведения окончили, номера дипломов)\nНаправление подготовки или специальность по диплому\nКвалификация по диплому";
                table.Cell(5, 2).Range.Text = txtEducation.Text;
                table.Cell(6, 1).Range.Text = "6. Послевузовское профессиональное образование: адъюнктура, докторантура (наименование образовательного или научного учреждения, год окончания)\nУчёная степень, учёное звание (когда присвоены, номера дипломов, аттестатов)";
                table.Cell(7, 1).Range.Text = "7. Какими иностранными языками и языками народов Российской Федерации владеете и в какой степени (читаете и переводите со словарем, читаете и можете объясняться, владеете свободно)";
                table.Cell(8, 1).Range.Text = ""; // пустая ячейка справа

                string fileName = $"{DateTime.Now:yyyyMMdd}. Анкета.docx";
                doc.SaveAs2(fileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка генерации анкеты: " + ex.Message);
            }
        }

        private void GenerateTitlePage()
        {
            try
            {
                var wordApp = new Word.Application();
                var doc = wordApp.Documents.Add();
                wordApp.Visible = true;

                doc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;
                doc.PageSetup.TopMargin = 70;
                doc.PageSetup.BottomMargin = 70;
                doc.PageSetup.LeftMargin = 70;
                doc.PageSetup.RightMargin = 70;

                void AddCentered(string text, int fontSize = 14, bool bold = false, int spaceAfter = 6)
                {
                    Word.Paragraph p = doc.Content.Paragraphs.Add();
                    p.Range.Text = text;
                    p.Range.Font.Name = "Times New Roman";
                    p.Range.Font.Size = fontSize;
                    p.Range.Bold = bold ? 1 : 0;
                    p.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                    p.SpaceAfter = spaceAfter;
                    p.Range.InsertParagraphAfter();
                }

                // Верхние строки
                AddCentered("МИНИСТЕРСТВО ТРАНСПОРТА РОССИЙСКОЙ ФЕДЕРАЦИИ", 12);
                AddCentered("ФЕДЕРАЛЬНОЕ ГОСУДАРСТВЕННОЕ АВТОНОМНОЕ", 12);
                AddCentered("ОБРАЗОВАТЕЛЬНОЕ УЧРЕЖДЕНИЕ ВЫСШЕГО ОБРАЗОВАНИЯ", 12);
                AddCentered("«РОССИЙСКИЙ УНИВЕРСИТЕТ ТРАНСПОРТА»", 12);
                AddCentered("(РУТ (МИИТ))", 12, false, 20);

                AddCentered("ИНСТИТУТ ТРАНСПОРТНОЙ ТЕХНИКИ И СИСТЕМ УПРАВЛЕНИЯ", 12, false, 12);
                AddCentered("Кафедра «Управление и защита информации»", 12, false, 40);

                AddCentered("Отчёт", 14, true, 6);
                AddCentered("Учебная практика", 12, false, 6);
                AddCentered("Задание 1", 12, false, 6);
                AddCentered("по дисциплине", 12, false, 6);
                AddCentered("Алгоритмизация и технологии программирования", 12, false, 20);

                AddCentered($"Вариант № {txtVariant.Text}", 12, false, 60);

                // Выполнил
                Word.Paragraph pStudent = doc.Content.Paragraphs.Add();
                pStudent.Range.Text = $"Выполнил: ст. гр. {txtGroup.Text}, {txtStudent.Text}";
                pStudent.Range.Font.Name = "Times New Roman";
                pStudent.Range.Font.Size = 12;
                pStudent.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                pStudent.Format.LeftIndent = 250;
                pStudent.SpaceAfter = 12;
                pStudent.Range.InsertParagraphAfter();

                // Проверил
                Word.Paragraph pChecker = doc.Content.Paragraphs.Add();
                pChecker.Range.Text = $"Проверил: {txtChecker.Text}";
                pChecker.Range.Font.Name = "Times New Roman";
                pChecker.Range.Font.Size = 12;
                pChecker.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                pChecker.Format.LeftIndent = 250;
                pChecker.SpaceAfter = 80;
                pChecker.Range.InsertParagraphAfter();

                // Город и год — в нижнем колонтитуле
                Word.Section section = doc.Sections[1];
                Word.HeaderFooter footer = section.Footers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary];
                Word.Paragraph pCity = footer.Range.Paragraphs.Add();
                pCity.Range.Text = $"{txtCityYear.Text}";
                pCity.Range.Font.Name = "Times New Roman";
                pCity.Range.Font.Size = 12;
                pCity.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                string fileName = $"{DateTime.Now:yyyyMMdd}. Титульный лист.docx";
                doc.SaveAs2(fileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка генерации титульного листа: " + ex.Message);
            }
        }
    }
}
